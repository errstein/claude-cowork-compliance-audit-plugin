#!/bin/bash
# Export audit logs to CSV or JSON
# Usage: export-logs.sh [format: csv|json] [output_path]

FORMAT="${1:-csv}"
OUTPUT="${2:-$HOME/Desktop/audit-export-$(date +%Y%m%d-%H%M%S).$FORMAT}"
LOG_FILE="$HOME/.compliance-audit/audit.jsonl"

if [ ! -f "$LOG_FILE" ]; then
  echo '{"error": "No audit log found at '"$LOG_FILE"'"}' >&2
  exit 1
fi

if [ "$FORMAT" = "csv" ]; then
  echo "timestamp,event,session_id,tool,exit_code" > "$OUTPUT"
  while IFS= read -r line; do
    TS=$(echo "$line" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('timestamp',''))")
    EV=$(echo "$line" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('event',''))")
    SID=$(echo "$line" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('session_id',''))")
    TN=$(echo "$line" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('tool',''))")
    EC=$(echo "$line" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('exit_code',''))")
    echo "$TS,$EV,$SID,$TN,$EC" >> "$OUTPUT"
  done < "$LOG_FILE"
else
  # JSON array export
  python3 -c "
import json, sys
lines = open('$LOG_FILE').readlines()
records = [json.loads(l) for l in lines if l.strip()]
with open('$OUTPUT', 'w') as f:
    json.dump(records, f, indent=2)
"
fi

echo "$OUTPUT"
