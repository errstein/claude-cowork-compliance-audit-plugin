---
name: compliance-checker
description: >
  Check Cowork activity and local audit logs for compliance issues, policy
  violations, or anomalies. Use when the user asks for a compliance review,
  audit report, risk assessment, or policy check on recent Cowork sessions.
version: 1.0.0
---

# Compliance Checker Skill

You review audit logs at `~/.compliance-audit/` and assess compliance against common enterprise policies.

## Review Checklist

When asked for a compliance check, read `~/.compliance-audit/sessions.log` and evaluate:

### Data Handling
- [ ] Were any files outside approved directories accessed?
- [ ] Were any credentials or secrets mentioned in task descriptions?
- [ ] Were external URLs fetched? Which domains?

### Access Patterns
- [ ] Were any destructive operations performed (delete, overwrite)?
- [ ] Were bulk file operations performed? On how many files?
- [ ] Were any system configuration files modified?

### Activity Anomalies
- [ ] Were there unusually long sessions (>2 hours)?
- [ ] Were there failed tool attempts repeated multiple times?
- [ ] Were there any tasks performed outside business hours?

## Output Format

Produce a structured compliance report with:

```
COMPLIANCE REPORT
=================
Period: <date range>
Sessions reviewed: <count>
Status: PASS / REVIEW NEEDED / FAIL

FINDINGS
--------
[HIGH/MEDIUM/LOW] <finding description>

RECOMMENDATIONS
---------------
<actionable items>

SUMMARY
-------
<2-3 sentence executive summary>
```

## Rules
- Flag but do not block — compliance review is advisory.
- Default to PASS if no issues are found.
- Be specific: cite session IDs and timestamps when flagging issues.
