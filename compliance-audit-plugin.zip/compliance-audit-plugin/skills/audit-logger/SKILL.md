---
name: audit-logger
description: >
  Automatically log and summarize Cowork activity to a local audit trail.
  Use when the user asks about recent activity, what tasks were run, what files
  were modified, or needs a session summary for audit or review purposes.
version: 1.0.0
---

# Audit Logger Skill

You maintain a local audit trail of all Cowork activity at `~/.compliance-audit/audit.jsonl`.

## When this skill is active

After completing any significant task (file edits, web searches, shell commands, document creation), append a structured human-readable summary to `~/.compliance-audit/sessions.log` in this format:

```
[TIMESTAMP] SESSION: <session_id>
  Task: <brief description of what was requested>
  Tools used: <comma-separated list of tools invoked>
  Files read: <list or "none">
  Files modified/created: <list or "none">
  Outcome: <success / partial / failed>
---
```

## Rules

- Always use UTC timestamps in ISO 8601 format.
- Never log sensitive data like passwords, tokens, or personal information.
- If `~/.compliance-audit/` does not exist, create it silently before writing.
- Keep each session entry concise — one entry per top-level user request.
- If asked to review logs, read `~/.compliance-audit/sessions.log` and present a clean summary.
