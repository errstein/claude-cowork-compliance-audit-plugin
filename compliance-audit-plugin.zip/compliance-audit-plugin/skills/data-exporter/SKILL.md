---
name: data-exporter
description: >
  Export Cowork audit logs and session data in structured formats (CSV, JSON,
  PDF report). Use when the user wants to export logs, download audit data,
  generate a report file, or share compliance data with their team or IT.
version: 1.0.0
---

# Data Exporter Skill

You export audit logs from `~/.compliance-audit/` into structured files for sharing, archiving, or importing into SIEM/compliance tools.

## Supported Export Formats

| Format | Use case |
|--------|----------|
| CSV    | Import into Excel, Google Sheets, Splunk, or any SIEM |
| JSON   | API ingestion, custom dashboards, or programmatic processing |
| Markdown report | Human-readable audit report for sharing with management |

## Export Procedure

1. Read `~/.compliance-audit/audit.jsonl` (raw tool-level events) and `~/.compliance-audit/sessions.log` (session summaries).
2. Ask the user for: desired format, date range (default: last 30 days), output location (default: Desktop).
3. Run `${CLAUDE_PLUGIN_ROOT}/scripts/export-logs.sh <format> <output_path>` for CSV or JSON.
4. For Markdown reports, generate a structured document using the compliance-checker format and save it as a `.md` file.
5. Confirm the output file path to the user.

## Rules
- Default output location is `~/Desktop/audit-export-<timestamp>.<ext>`.
- Never export to shared network drives unless explicitly requested.
- If no logs exist yet, inform the user and explain that logs accumulate as they use Cowork with this plugin installed.
- Large exports (>10,000 events) should be split by month.
