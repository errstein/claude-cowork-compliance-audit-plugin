# Compliance Audit Plugin for Claude Cowork

Adds local audit logging, compliance review, and data export to Claude Cowork.

> **Note:** Because Cowork runs locally, this plugin stores all logs on your
> machine at `~/.compliance-audit/`. Logs are never sent to Anthropic or any
> external server.

## Features

| Feature | How to trigger |
|---------|---------------|
| Auto-log every task | Automatic — no action needed |
| View recent activity | `/view-audit-log` |
| Compliance report | `/compliance-report` |
| Export logs (CSV/JSON/MD) | `/export-logs` |
| Add a manual note | `/log-note` |

## Installation

1. Open Claude Desktop → switch to **Cowork** tab.
2. Click **Customize** in the left sidebar.
3. Click **Browse plugins** → **Upload plugin**.
4. Select the `compliance-audit-plugin` folder (or the `.plugin` zip file).
5. Click **Install**.

After installation, type `/` in any Cowork task to see available commands.

## Log File Locations

| File | Contents |
|------|----------|
| `~/.compliance-audit/audit.jsonl` | Raw tool-level events (one JSON object per line) |
| `~/.compliance-audit/sessions.log` | Human-readable session summaries |

## Limitations

- Logs are local only — not synced to any cloud or Anthropic servers.
- Hooks require macOS or Windows with Claude Desktop ≥ the February 2026 update.
- This plugin does not replace enterprise-grade SIEM solutions; it is a
  best-effort local audit trail for teams that need basic governance on
  regulated Cowork activity.

## Customization

Edit any `SKILL.md` in the `skills/` folder to adjust:
- Which files/directories to flag in compliance checks
- The output format of reports
- Which domains are considered "approved" for web fetches
