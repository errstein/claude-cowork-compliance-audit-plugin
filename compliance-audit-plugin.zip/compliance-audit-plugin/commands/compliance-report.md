---
description: Generate a compliance report from recent Cowork activity
disable-model-invocation: false
---

Use the compliance-checker skill to review `~/.compliance-audit/sessions.log`.

Ask the user:
1. What time period to cover (default: last 30 days)
2. Whether they want to save the report to a file

Then run a full compliance review and output the structured COMPLIANCE REPORT.

If the user wants to save it, write the report to `~/Desktop/compliance-report-<YYYY-MM-DD>.md` and confirm the path.
