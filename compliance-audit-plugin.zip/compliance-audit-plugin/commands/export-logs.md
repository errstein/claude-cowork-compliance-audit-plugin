---
description: Export audit logs to CSV, JSON, or a Markdown report
disable-model-invocation: false
---

Use the data-exporter skill to export audit logs.

Ask the user to choose:
1. **Format**: CSV, JSON, or Markdown report
2. **Date range**: All time, last 7 days, last 30 days, or custom range
3. **Destination** (default: Desktop)

Then perform the export using the appropriate method:
- For CSV/JSON: run `${CLAUDE_PLUGIN_ROOT}/scripts/export-logs.sh`
- For Markdown: generate the report using the compliance-checker format

Confirm the exported file path when done and show the file size.
