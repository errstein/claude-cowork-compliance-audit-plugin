---
description: View recent Cowork audit log entries
disable-model-invocation: false
---

Read `~/.compliance-audit/sessions.log`. If the file doesn't exist, tell the user no activity has been logged yet and that logs will start accumulating after their next Cowork task.

If the file exists, show the last 20 entries in a clean, readable format. Group entries by date. Highlight any entries marked as "failed" in red or with a ⚠️ symbol.

Ask the user if they want to:
1. See more entries (specific date range)
2. Run a compliance check on these logs
3. Export the logs to a file
