---
description: Manually add a note or event to the audit log
disable-model-invocation: false
---

Ask the user what they want to log. This could be:
- A manual note about an action taken outside Cowork
- A policy acknowledgment
- An incident record

Then append a structured entry to `~/.compliance-audit/sessions.log` in this format:

```
[TIMESTAMP] MANUAL ENTRY
  Note: <user's note>
  Logged by: user
---
```

Confirm the entry was written successfully.
